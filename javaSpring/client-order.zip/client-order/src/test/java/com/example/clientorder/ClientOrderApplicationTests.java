package com.example.clientorder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
